<?php
   include('DBConn.php');
   $output = NULL;
?>

<html>

 <head>

 <link rel ="stylesheet" href ="Css.css">

 </head>
 
 <body background="img/backround.jpg" link="#000">

 <div class="center">
    <h1>User Approval</<h1>
	
	<center>
	<hr style="width:35%">
	<a href =""></a>
	<a href="bookSales.php">Books sales</a>
	
	<table id="users">
	   <tr>
	      <th>ID</th>
		  <th>First Name</th>
		  <th>Surname</th>
		  <th>Student Number</th>
		  <th>Email</th>
		  <th>Password</th>
		  <th>Action</th>
	   </tr>
	   
	   <?php
	      $query = "SELECT * FROM tblusers WHERE vstatus = '1'";
		  $result = mysqli_query($conn,$query);
		  while($row = mysqli_fetch_array($result)){
		?>
		<tr>
		   <td><?php echo $row['uid'];?></td>
		   <td><?php echo $row['fname'];?></td>
		   <td><?php echo $row['lname'];?></td>
		   <td><?php echo $row['stnum'];?></td>
		   <td><?php echo $row['email'];?></td>
		   <td><?php echo $row['password'];?></td>
		   <td>
		      <form action="Approval_page.php" method="POST">
			     <input type="hidden" name="id" value="<?php echo $row['uid'];?>"/>
				 <input type="submit" name="approve" value="Approve"/>
				 <input type="submit" name="deny" value="Deny"/>
			  </form>
			
		   </td>
		</tr>
	</table>
	
	
	<?php
	      }
	?>
	
 </div>
 <form action="Approval_page.php" method="POST">
   <div>
      <input type="submit" name="next" value="Next"/>
   </div>
   <div>
      <input type="submit" name="back" value="Back"/>
   </div>
 </form>
 
 
 
 
 <?php
 
 //Code to approve user
 if(isset($_POST['approve'])){
	 
	 $id = $_POST['id'];
	 
	 
	 $select = "UPDATE tblusers SET vstatus = '0' WHERE id = '$id'";
	 $result = mysqli_query($conn,$select);
	 
	 
	 echo "User Approved";
	 $id = $_POST['id'];
	 $id = NULL;
	 
 }
 //Code to deny user
 if(isset($_POST['deny'])){
	 
	 $id = $_POST['id'];
	 
	 $select = "DELETE FROM tblusers WHERE id = '$id'";
	 $result = mysqli_query($conn,$select);
	 
	 //$output = "User Approved";
	 echo "User Denied";
	 $id = NULL;
	 
 }
 
 if(isset($_POST['next'])){
	 header("location:userBookViewing.php");
 }
 
 if(isset($_POST['back'])){
	 header("location:login.php");
 }
	
 
 ?>
 

  
 </body>
</html>