html>
<head>
<title>BOOKSTORE</title>

/*Opening text styles */
  <style>
    /* CSS Styles */
	/*for manu*/
    ul.menu {
      list-style-type: none;
      margin: 0;
      padding: 0;
      background-color: green;
    }
    
    ul.menu li {
      display: inline-block;
    }
    
    ul.menu li a {
      display: block;
      padding: 10px 70px;
      text-decoration: none;
	  font-size: 22px;
      color: white;
    }
    
    ul.menu li a:hover {
      background-color: #ddd;
    }
	/*for header*/
	ul.h1 {text-align: center;}
	ul.h1 {background-color: white}
	
	/*for paragraph*/
	ul.p{text-align: center}
	ul.p{background-color:orange}
	/*for h2*/
	h2{text-align: center}
	/*for footer*/
	ul.ff
	{ 
      background-color: green;
       padding: 10px;
       text-align: center;
     color: white;
    }
	
	
  </style>
</head>
/*Closing text styles and opening body
Connecting Homepage menu bar */ 

<body>

   <ul class="h1">
    <h1>
	  welcome to C&B bookstore
	
	</h1>

  <ul class="menu">
    <li><a href="Home.php">Home</a></li>
    <li><a href="User.php">Login</a></li>
	<li><a href="Admin.php">Admin</a></li>
    <li><a href="Books.php">Books</a></li>
    <li><a href="Order.php">Order</a></li>
	
  </ul>
  
  
  <h2>
     C&B BEST SELLING BOOKS
  </h2>
  
  
  <ul class ="center">
  
        
	  <div>
          <img src="richdad.jpeg"width="350" hight="300" alt=""/>
          <img src="R.jpg"width="350" hight="200"  alt=""/>
          <img src="Think-like-monk.jpeg"width="350" hight="300"  alt=""/>
         
		  
    </div>
  
  
  
  
  </ul>
    <h2>
     C&B BOOK GANDRAS
  </h2>
  
  <div style="background-color:lime">
  
       FICTION<BR>
	   DRAMA<br>
       CHILDREN<br>
	   SELF-DEVELOPMENT<br>
	   NON-FICTION<br>
	   CRIME<br>
	   
  </div>

  <ul class="p">
    <p>
	 If you're a book lover, library or school in search of an easy way to fill your bookshelves with must-reads,<br>
	 our online Book Gift Registry is here to help!<br>

     Whether it's family and friends who want to shower you with gifts or strangers looking for a great cause<br>
       – this registry simplifies purchasing literary treasures.<br>

     Add any desired titles and share them for others <br>
	 shopping has never been so convenient, effortless…and fun!<br>

     Get all the awesome reads on your wishlist today by creating your own online Book Gift Registry.
	 
     </p>
</ul>


  /*Closing admin form group
		
		Footer*/
  <ul class="ff">
  <footer>

</footer>
</ul>
</body>
</html>
