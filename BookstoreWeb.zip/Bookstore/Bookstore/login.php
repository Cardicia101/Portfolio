<?php


    session_start();
	unset($_SESSION['email']);  
	include "DBConn.php";
	include 'createTable.php'; 
	
	$output = NULL;
    $email = $password = "";

   //Login button 
    if(isset($_POST['login']))
    {
    
        $_SESSION['email'] = $_POST['email'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $hpass = md5($password);

        $query = "SELECT email, password FROM tblusers WHERE email = '$email' AND password = '$hpass'";
        
        $result = mysqli_query($conn,$query);

        $row = mysqli_fetch_array($result);

        if(empty($email))
        {
            $output = "Enter username as ST********@rcconnect.edu.za";
        }

        else 
        { 
             if($row['email'] == $email && $row['password'] == $hpass) 
             {
                 header("location:userBookViewing.php");
             }
            else 
            {
               
				echo "Enter correct Username\Password";
            }
        
        }
        
        
	} 
	

	if(isset($_POST['register']))
    {
		header("location:registration.php");
	}

?>

<html>
 <head>
 
 <link rel ="stylesheet" href ="Css.css">
  <style>
 
    ul.menu {
      list-style-type: none;
      margin: 0;
      padding: 0;
      background-color: purple;
    }
    
    ul.menu li {
      display: inline-block;
    }
    
    ul.menu li a {
      display: block;
      padding: 10px 60px;
      text-decoration: none;
	  font-size: 22px;
      color: white;
    }
    
    ul.menu li a:hover {
      background-color: #ddd;
    }
	
	ul.h1 {text-align: center;}
	ul.h1 {background-color: white}
	
	
	ul.p{text-align: center}
	ul.p{background-color:orange}
	
	h2{text-align: center}
	
	ul.ff
	{ 
      background-color: green;
       padding: 10px;
       text-align: center;
     color: white;
    }

		</style>
</head>


 
<body background="img/Screen.png" link="#000">

 <h1>User Login</h1> 
 
  <ul class="menu">
    <li><a href="login.php">Login</a></li>
	<li><a href="Admin.php">Admin</a></li>
    <li><a href="userBookViewing.php">Books</a></li>
    <li><a href="registration.php">Register</a></li>
	
  </ul>
  
<form action="" method="post"> 
  Username:<input type="email" name ="email"><br/><br/>
  Password:<input type="password" name ="password"><br/><br/><br/><br/>
  :<input type="submit" name ="login" value="Login">
  :<input type="submit" name="register" value="Register">
  
  <p>Click here to Login as: <a href="Admin.php">Admin</a></p>
  
  <ul class="p">
    <p>
	 If you're a book lover, library or school in search of an easy way to fill your bookshelves with must-reads,<br>
	 our online Book Gift Registry is here to help!<br>

     Whether it's family and friends who want to shower you with gifts or strangers looking for a great cause<br>
       – this registry simplifies purchasing literary treasures.<br>

     Add any desired titles and share them for others <br>
	 shopping has never been so convenient, effortless…and fun!<br>

     Get all the awesome reads on your wishlist today by creating your own online Book Gift Registry.
	 
     </p>
</ul>

 
  </form> 
 </body>
</html>