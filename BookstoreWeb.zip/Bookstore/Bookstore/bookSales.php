<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books Selling</title>
    <link rel ="stylesheet" href ="Css.css">
    
</head>
<body>
    
    <div class="Add_product">
<form method="post" action="">
<table >
<tr>
    <td>Book Title</td><td><input type="text" name="booktitle"></td>
</tr>
<tr>
    <td>Price</td><td><input type="text" name="price"></td>
</tr>
<tr>
    <td>
        <button class="btn" type="submit" name="add">Add</button>
    </td>
</tr>

</table>
</form>
    </div>
    
</body>
</html>